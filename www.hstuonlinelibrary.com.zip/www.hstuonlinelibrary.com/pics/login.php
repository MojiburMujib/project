<?php
  include 'config.php';
?>

<html>
<head>
<link rel="stylesheet" href="style.css"></link>
<title>HSTU Online Library || Hajee Mohammad Danesh Science and Technology University</title>

</head>
<body id="b" bgcolor="#C0C0C0">
<h2 align="center" class="h">Welcome to Online Library</h2>
<center>
<div id="d">
<img src="login.png" class="img"></img>


<center><form action="login.php" method="POST">

<b><label>Email</label>
<input name="email" type="email" id="form" placeholder="Enter your email" required>
</input>
<b><label>Password</label>
<input name="pass" type="password" id="form" placeholder="Enter your Password" required>
</input>


<input name="login" type="submit" id="button" value="LOGIN">
</input>
<a href="signup.php"><input name="reg" type="button" id="button" value="SIGN-UP">
</input>
</a>
<a href="index.php"><input name="home" type="button" id="button" value="BACK TO HOMEPAGE">
</input>
</a>

</form></center>

</center>



<?php

    if(isset($_POST['login'])){
		
		$email= $_POST['email'];
		$pass=$_POST['pass'];
		
		$check = "select*from user where email='$email' AND password ='$pass'";
		$check_work= mysqli_query($con,$check);
		
		if($check_work){
			if(mysqli_num_rows($check_work) > 0 ){
				
				echo"
				<script>
				alert('You are Successfully  Logged in');
				window.location.href='index.php';
				</script>
				";
			}else{	
				echo"
				<script>
				alert('Password or Email not Found ');
				window.location.href('signup.php');
				</script>
				";
			}		
		}else{
			
			
				echo"
				<script>
				alert('Database Error  ');
				window.location.href('signup.php');
				</script>
				";
		}	
	}else{		
	}
?>
</div>
</body>

</html>
