<?php
  include 'config.php';
?>

<html>
	<head>
		<title>HSTU Online Library || Hajee Mohammad Danesh Science and Technology University</title>
		<meta charset="UTF-8" />
		<meta name="keywords" content="hstu, online, library, hajee mohammad danesh science and technology university, hajee danesh, online library hstu;
			hajee mohammad danesh science & technology university, hstu library, hstu online library, hstu dinajpur, hstu official website, 
			hstu.ac.bd, www.hstu.ac.bd, varsity, university, dinajpur, official website of hstu; hstu website" />
		<meta name="description" content="Welcome to the website of HSTU Online Library. 
			It is the official website of the library of Hajee Mohammad Danesh Science and Technology University (HSTU). 
			It is the online version of HSTU library." />
		<meta name="author" content="Md. Mojibur Rahman (Mujib)" />
		<link rel="stylesheet" href="stylehome.css"></link>
		<link rel="stylesheet" href="style.css"></link>
	</head>
	
	<body <!--style="font-family:Comic Sans MS;"-->
		<table style="width:100%; border-collapse:collapse;">
			<tr>
				<td class="l">
				</td>
				<td class="m">
					<header id="page_top">
						<div>
							<h1 align="center">
								<p>
									<img title="HSTU Logo" src ="pics/varsity.jpg" height="30" width="40" alt="HSTU Logo" />
									<a id="ms" href="index.php">University Online Library</a>
									<img title="HSTU Logo" src ="pics/varsity.jpg" height="30" width="40" alt="HSTU Logo" />
								</p>
							</h1>
						</div>
						<h2>
							<p>
								<marquee style="font-family:Comic Sans MS; background-color:black; color:white;" scrollamount="2" title="মোদের সমৃদ্ধ পাঠশালা  -  হাজী মোহাম্মদ দানেশ বিজ্ঞান ও প্রযুক্তি বিশ্ববিদ্যালয় (হাবিপ্রবি)">
										<i>&nbsp;* Our Enriched School *&nbsp;</i>
								</marquee>
							</p>
						</h2>
						<b>
							<div> 
								<nav>
									<ul>
										<li><a title="Main Page - মূল পাতা" href="index.php">Main</a>
										</li>
										<li><a title="Services - সেবাসমূহ" href="services.php">Services  <span><img src="pics/dd.png"></span></a>
											<ul>
												<li><a href="services.php">Make pdf <span><img src="pics/rr.png"></span></a>
													<ul>
														<li><a href="services.php">From doc</a></li>
														<li><a href="services.php">From pic</a></li>
													</ul>
												</li>
											</ul>
										</li>
										<li><a title="Books - বইসমূহ " href="books.php">Books <span><img src="pics/dd.png"></span></a>
											<ul>
												<li><a href="index.php">Agriculture <span><img src="pics/rr.png"></span></a>
													<ul>	
														<li><a href="books_cse_cse.php">Agriculture</a></li>
														<li><a href="books_cse_cse.php">Agriculture and Agrobusiness</a></li>
													</ul>
												</li>
												<li><a href="index.php">Computer Science and Engineernig <span><img src="pics/rr.png"></span></a>
													<ul>	
														<li><a href="books_cse_cse.php">CSE</a></li>
														<li><a href="books_cse_cse.php">ECE</a></li>
														<li><a href="books_cse_cse.php">EEE</a></li>
													</ul>
												</li>
												<li><a href="index.php">Business Studies <span><img src="pics/rr.png"></span></a>
													<ul>	
														<li><a href="books_cse_cse.php">BBA</a></li>
														<li><a href="books_cse_cse.php">BSS</a></li>
													</ul>
												</li>
												<li><a href="books_cse_cse.php">Fisheries</a>
												<!--<ul>	
														<li><a href="index.php">Fisheries</a></li>
													</ul>-->
												</li>
												<li><a href="index.php">Engineering <span><img src="pics/rr.png"></span></a>
													<ul>	
														<li><a href="books_cse_cse.php">FPE</a></li>
														<li><a href="books_cse_cse.php">AE</a></li>
														<li><a href="books_cse_cse.php">Architechture</a></li>
														<li><a href="books_cse_cse.php">Civil</a></li>
														<li><a href="books_cse_cse.php">Mechanical</a></li>
													</ul>
												</li>
												<li><a href="books_cse_cse.php">Veterinary and Animal Science</a>
												<!--<ul>	
														<li><a href="index.php">DVM</a></li>
													</ul>-->
												</li>
												<li><a href="index.php">Science <span><img src="pics/rr.png"></span></a>
													<ul>	
														<li><a href="books_cse_cse.php">Mathematics</a></li>
														<li><a href="books_cse_cse.php">Statistics</a></li>
														<li><a href="books_cse_cse.php">Chemistry</a></li>
														<li><a href="books_cse_cse.php">Physics</a></li>
													</ul>
												</li>
												<li><a href="index.php">Social Science and Humanitics <span><img src="pics/rr.png"></span></a>
													<ul>	
														<li><a href="books_cse_cse.php">English</a></li>
														<li><a href="books_cse_cse.php">Economics</a></li>
														<li><a href="books_cse_cse.php">Social Science</a></li>
													</ul>
												</li>
												<li><a href="index.php">Postgraduates Studies <span><img src="pics/rr.png"></span></a>
													<ul>	
														<li><a href="books_cse_cse.php">PhD</a></li>
														<li><a href="books_cse_cse.php">MS</a></li>
													</ul>
												</li>
											</ul>
										</li>
										<li><a title="Sheets - স্মরলিপিসমূহ" href="sheets.php">Sheets <span><img src="pics/dd.png"></span></a>
											<ul>
												<li><a href="index.php">Agriculture <span><img src="pics/rr.png"></span></a>
													<ul>	
														<li><a href="books_cse_cse.php">Agriculture</a></li>
														<li><a href="books_cse_cse.php">Agriculture and Agribusiness</a></li>
													</ul>
												</li>
												<li><a href="index.php">Computer Science and Engineernig <span><img src="pics/rr.png"></span></a>
													<ul>	
														<li><a href="books_cse_cse.php">CSE</a></li>
														<li><a href="books_cse_cse.php">ECE</a></li>
														<li><a href="books_cse_cse.php">EEE</a></li>
													</ul>
												</li>
												<li><a href="index.php">Business Studies <span><img src="pics/rr.png"></span></a>
													<ul>	
														<li><a href="books_cse_cse.php">BBA</a></li>
														<li><a href="books_cse_cse.php">BSS</a></li>
													</ul>
												</li>
												<li><a href="books_cse_cse.php">Fisheries</a>
												<!--<ul>	
														<li><a href="index.php">Fisheries</a></li>
													</ul>-->
												</li>
												<li><a href="index.php">Engineering <span><img src="pics/rr.png"></span></a>
													<ul>	
														<li><a href="books_cse_cse.php">FPE</a></li>
														<li><a href="books_cse_cse.php">AE</a></li>
														<li><a href="books_cse_cse.php">Architechture</a></li>
														<li><a href="books_cse_cse.php">Civil</a></li>
														<li><a href="books_cse_cse.php">Mechanical</a></li>
													</ul>
												</li>
												<li><a href="books_cse_cse.php">Veterinary and Animal Science</a>
												<!--<ul>	
														<li><a href="index.php">DVM</a></li>
													</ul>-->
												</li>
												<li><a href="index.php">Science <span><img src="pics/rr.png"></span></a>
													<ul>	
														<li><a href="books_cse_cse.php">Mathematics</a></li>
														<li><a href="books_cse_cse.php">Statistics</a></li>
														<li><a href="books_cse_cse.php">Chemistry</a></li>
														<li><a href="books_cse_cse.php">Physics</a></li>
													</ul>
												</li>
												<li><a href="index.php">Social Science and Humanitics <span><img src="pics/rr.png"></span></a>
													<ul>	
														<li><a href="books_cse_cse.php">English</a></li>
														<li><a href="books_cse_cse.php">Economics</a></li>
														<li><a href="books_cse_cse.php">Social Science</a></li>
													</ul>
												</li>
												<li><a href="index.php">Postgraduates Studies <span><img src="pics/rr.png"></span></a>
													<ul>	
														<li><a href="books_cse_cse.php">PhD</a></li>
														<li><a href="books_cse_cse.php">MS</a></li>
													</ul>
												</li>
											</ul>
										</li>
										<li><a title="Previous Exams' Questions - বিগত পরীক্ষাসমূহের প্রশ্নসমূহ" href="questions.php">Questions <span><img src="pics/dd.png"></span></a>
											<ul>
												<li><a href="index.php">Agriculture <span><img src="pics/rr.png"></span></a>
													<ul>	
														<li><a href="books_cse_cse.php">Agriculture</a></li>
														<li><a href="books_cse_cse.php">Agriculture and Agribusiness</a></li>
													</ul>
												</li>
												<li><a href="index.php">Computer Science and Engineernig <span><img src="pics/rr.png"></span></a>
													<ul>	
														<li><a href="books_cse_cse.php">CSE</a></li>
														<li><a href="books_cse_cse.php">ECE</a></li>
														<li><a href="books_cse_cse.php">EEE</a></li>
													</ul>
												</li>
												<li><a href="index.php">Business Studies <span><img src="pics/rr.png"></span></a>
													<ul>	
														<li><a href="books_cse_cse.php">BBA</a></li>
														<li><a href="books_cse_cse.php">BSS</a></li>
													</ul>
												</li>
												<li><a href="books_cse_cse.php">Fisheries</a>
												<!--<ul>	
														<li><a href="index.php">Fisheries</a></li>
													</ul>-->
												</li>
												<li><a href="index.php">Engineering <span><img src="pics/rr.png"></span></a>
													<ul>	
														<li><a href="books_cse_cse.php">FPE</a></li>
														<li><a href="books_cse_cse.php">AE</a></li>
														<li><a href="books_cse_cse.php">Architechture</a></li>
														<li><a href="books_cse_cse.php">Civil</a></li>
														<li><a href="books_cse_cse.php">Mechanical</a></li>
													</ul>
												</li>
												<li><a href="index.php">Veterinary and Animal Science</a>
												<!--<ul>	
														<li><a href="index.php">DVM</a></li>
													</ul>-->
												</li>
												<li><a href="index.php">Science <span><img src="pics/rr.png"></span></a>
													<ul>	
														<li><a href="books_cse_cse.php">Mathematics</a></li>
														<li><a href="books_cse_cse.php">Statistics</a></li>
														<li><a href="books_cse_cse.php">Chemistry</a></li>
														<li><a href="books_cse_cse.php">Physics</a></li>
													</ul>
												</li>
												<li><a href="index.php">Social Science and Humanitics <span><img src="pics/rr.png"></span></a>
													<ul>	
														<li><a href="books_cse_cse.php">English</a></li>
														<li><a href="books_cse_cse.php">Economics</a></li>
														<li><a href="books_cse_cse.php">Social Science</a></li>
													</ul>
												</li>
												<li><a href="index.php">Postgraduates Studies <span><img src="pics/rr.png"></span></a>
													<ul>	
														<li><a href="books_cse_cse.php">PhD</a></li>
														<li><a href="books_cse_cse.php">MS</a></li>
													</ul>
												</li>
											</ul>
										</li>
										<li><a title="Login - চুক্তিবদ্ধ হোন" href="login.php">Login</a></li>
										<li><a title="About Us - মোদের সম্পর্কে" href="about.php">About</a></li>
										<li><a title="Contact - যোগাযোগ" href="contact.php">Contact</a></li>
										<li><a title="Issue Books || বই প্রেরণ" href="issue.php">Issue Books</a></li>
									</ul>
								</nav>
							</div>
						</b>
					</header>
					
					<main>
						<div id="page_inside">
							<article id="article1">
								<table border="0px" style="width:100%; border-collapse:collapse;">
									<tr>
										<td>
											<br/>
											<h3>
												<br/> <u><a href="signup.php">Sign-Up Page</a></u>
											</h3>
											<br/>
										</td>
										<td align="right">
											<form method="post">
												<b title="Search Your Book - বই অনুসন্ধান করুন" style="color:red">Search Your Book</b> <input size="30" type="text" name="search" placeholder="Type Book title or Writer name" required>
												<input type="submit" name="submit" value="Search" style="background:black; color:white; font-size:19px" title="Click to Search - অনুসন্ধান করতে ক্লিক করুন">
											</form>
										</td>
										<td align="right">
											<b class="clockStyle" id="clockDisplay"></b>
										</td>
									</tr>
									<tr>
										<td align="center" valign="top" colspan="3">
											<center>
											<div id="d">
												<img src="reg.png" class="img"></img>

												<center><form action="signup.php" method="POST">
												<b/><label>Name</label>
												<input name="name" type="text" id="form" placeholder="Enter your name" required>
												</input>
												<br/><label>Student ID</label>
												<input name="sid" type="number" id="form" placeholder="Enter your student ID" required>
												</input>
												
												<br/><label>Email</label>
												<input name="email" type="email" id="form" placeholder="Enter your email" required>
												</input>
												<br/><label>Password</label>
												<input name="pass" type="password" id="form" placeholder="Enter your Password" required>
												</input>
												<br/><label>Confirm Password</label>
												<input name="cpass" type="password" id="form" placeholder="Confirm your Password" required>
												</input>
												
												<br/>
												<input name="signup" type="submit" id="button" value="SIGN-UP">
												</input>
												<br/>
												<a href="login.php"><input name="back" type="button" id="button" value="BACK TO SIGN-IN">
												</input></a>

												</form></center>

												</center>
												<?php
												//coding 

												if(isset($_POST['signup'])){
													
													$name = $_POST['name'];
													$sid = $_POST['sid'];
													$email = $_POST['email'];
													
													$pass = $_POST['pass'];
													$cpass = $_POST['cpass'];
													
													if($pass==$cpass){
														
														$query= "select*from user where email='$email'";
														$query_run= mysqli_query($con,$query);
														if($query_run){
															
															if(mysqli_num_rows($query_run) >0){
																
																echo "
														<script>
														alert('User ALready Registered ');
														window.location.href='login.php';
														</script>
														";	
															}else{
																
													$insertion= "insert into user values('$name','$sid','$email','$pass')";
													
															   
																$insertion_run = mysqli_query($con,$insertion);
																
																if($insertion_run ){
																	
																	echo "
														<script>
														alert('Registration Successful ');
														window.location.href='index.php';
														</script>
														";
																	
																}else{
																	
																		echo "
														<script>
														alert('Registration Failed  ');
														window.location.href='signup.php';
														</script>
														";
																}		
															}
														}else{
															echo "
														<script>
														alert('Database Problem');
														window.location.href='signup.php';
														</script>
														";	
														}
													}
													else{
														echo "
														<script>
														alert('Password & Confirm Password not match');
														window.location.href='signup.php';
														</script>
														";
													}	
												}
												else{
													
													
												}
												?>

											</div>
										</td>
									</tr>
								</table>
						</section>
					</aside>
					
					<p>Thank You!</p>
					
					<footer id="page_tail">
						<details>
							<summary>Copyright &copy; 2019-Present.</summary>
								- by Mujib<br />
								<font size="2" color="black">
									- All content and graphics on this web site are the property of the company "Mujib'S World Inc".
								</font>
						</details>
					</footer>
					
					<div style="background:green">
						<h5>Search My LINKS</h5>
						<a target="_blank" href="http://www.google.com">Google</a>
					</div>
					
					<!--<center>
						<input type="text" size="26" />
						<input type="mail" size="26" />
						<input type="file" size="26" />
					</center><br />-->
					
					<hr />
					
					<form method="post" action="/cgibin/example.cgi">
						Enter Your Comments:<br>
						<textarea wrap="virtual" name="Comments" rows="3" cols="20" maxlength="100"></textarea><br>
						<input type="Submit" value="Submit">
						<input type="Reset" value="Clear">
					</form>
					
					<marquee style="background-color:black; color:white;" scrollamount="6" loop="-1">
						<b>পড়! তোমার রবের নামে, যিনি তোমাকে সৃষ্টি করেছেন</b>
					</marquee>
				</td>
				<td class="r">
				</td>
			</tr>
		</table>
		
		<script type="text/javascript" language="javascript"> 
			function renderTime(){
				var currentTime = new Date();
				var diem = "AM";
				var h = currentTime.getHours();
				var m = currentTime.getMinutes();
				var s = currentTime.getSeconds();
				
				if(h==0){
					h = 12;					
				}
				else if(h>12){
					h=h-12;
					diem="PM";
				}
				if(h<10){
					h = "0" + h;
				}
				if(m<10){
					m = "0" + m;
				}
				if(s<10){
					s = "0" + s;
				}
				
				var myClock = document.getElementById('clockDisplay');
				myClock.textContent = h + ":" + m + ":" + s + " " + diem;
				myClock.innerText = h + ":" + m + ":" + s + " " + diem;
					
				setTimeout('renderTime()',1000);
			}
			renderTime();
		</script>
	</body>
</html>
