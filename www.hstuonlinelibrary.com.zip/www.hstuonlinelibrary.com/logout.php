<?php
session_start();
session_destroy();
echo"
		<script>
		alert('You have been signed out!');
		window.location.href='index.php';
		</script>
		";
?>