<!DOCTYPE html>
<html>
	<head>
		<title>HSTU Online Library || Hajee Mohammad Danesh Science and Technology University</title>

		<meta charset="UTF-8" />

		<meta name="keywords" content="hstu, online, library, hajee mohammad danesh science and technology university, hajee danesh, online library hstu;
			hajee mohammad danesh science & technology university, hstu library, hstu online library, hstu dinajpur, hstu official website, 
			hstu.ac.bd, www.hstu.ac.bd, varsity, university, dinajpur, official website of hstu; hstu website" />

		<meta name="description" content="Welcome to the website of HSTU Online Library. 
			It is the official website of the library of Hajee Mohammad Danesh Science and Technology University (HSTU). 
			It is the online version of HSTU library." />

		<meta name="author" content="Md. Mojibur Rahman (Mujib)" />

		<style type="text/css">
			body{
				width:100%;
				padding:0px;
				margin:0px;
			}
			#ms{
				font-family:Comic Sans MS;
				text-decoration:none;
				border-radius:12px;
				font-size:40px;
				color:green;
				background-color:yellow;
				padding:5px;
				padding-left:10px;
				padding-right:10px;
			}
			td.l{
				background-image: url("pics/horizontal.png");
				background-position: top left;
				width:10%;
			}
			td.m {
				padding-left:5%;
				padding-right:5%;
				width:80%;
				background-color:Silver;
			}
			td.r{
				background-image: url("pics/horizontal-copy.png");
				background-position: top right;
				width:10%;
			}
			nav ul{
				background-color:Silver;
				list-style:none;
				margin:0px;
		   		padding:2px;
			}
			nav ul li{
				background-color:lime; 
				border:2px Solid Maroon; /* border-size:2px; border-style:Solid; border-color:Maroon; */
				border-radius:10px;
				width:10%;
				height:30px;
				line-height:30px;
				text-align:center;
				margin:2px;
				float:left;
				position:relative;
			}
			nav ul li a{
				text-decoration:none;
				color:purple;
				display:block;
			}
			nav ul ul{
				position:absolute;
				display:none;
			}
			nav ul li:hover > ul{
				display:block;
			}
			nav ul li:hover > ul > li{
				width:300px;
				white-space:nowrap;
			}
			nav ul ul ul{
				margin-left:300px;
				top:0px;
			}
			nav ul li:hover > ul ul li{
				width:250px;
			}
			/* mouse over link */
			nav li:hover a{
				background-color:purple;
				color:lime;
				border-radius:6px;
			}
			nav li li:hover a{
				background-color:Olive;
				color:Maroon;
				border-radius:6px;
			}
			li:hover li:hover li:hover a{
				background-color:black;
				color:white;
				border-radius:6px;
			}
			
			/* selected link */
			nav a:active{
				background-color: pink;
				color: Maroon;
				border-radius:8px;
			}
			.clockStyle{
				 background-color:Maroon;
				 color:white;
				 padding:6px;
				 display:inline;
			}
	    </style>
	</head>
	
	<body <!--style="font-family:Comic Sans MS;"-->
		<table style="width:100%; border-collapse:collapse;">
			<tr>
				<td class="l">
				</td>
				<td class="m">
					<header id="page_top">
						<div>
							<h1 align="center">
								<p>
									<img title="HSTU Logo" src ="pics/varsity.jpg" height="30" width="40" alt="HSTU Logo" />
									<a id="ms" href="index.php">University Online Library</a>
									<img title="HSTU Logo" src ="pics/varsity.jpg" height="30" width="40" alt="HSTU Logo" />
								</p>
							</h1>
						</div>
						<h2>
							<p>
								<marquee style="font-family:Comic Sans MS; background-color:black; color:white;" scrollamount="2" title="মোদের সমৃদ্ধ পাঠশালা  -  হাজী মোহাম্মদ দানেশ বিজ্ঞান ও প্রযুক্তি বিশ্ববিদ্যালয় (হাবিপ্রবি)">
										<i>&nbsp;* Our Enriched School *&nbsp;</i>
								</marquee>
							</p>
						</h2>
						<b>
							<div> 
								<nav>
									<ul>
										<li><a title="Main Page - মূল পাতা" href="index.php">Main</a>
										</li>
										<li><a title="Services - সেবাসমূহ" href="services.php">Services  <span><img src="pics/dd.png"></span></a>
											<ul>
												<li><a href="services.php">Make pdf <span><img src="pics/rr.png"></span></a>
													<ul>
														<li><a href="services.php">From doc</a></li>
														<li><a href="services.php">From pic</a></li>
													</ul>
												</li>
											</ul>
										</li>
										<li><a title="Books - বইসমূহ " href="books.php">Books <span><img src="pics/dd.png"></span></a>
											<ul>
												<li><a href="index.php">Agriculture <span><img src="pics/rr.png"></span></a>
													<ul>	
														<li><a href="index.php">Agriculture</a></li>
														<li><a href="index.php">Agriculture and Agrobusiness</a></li>
													</ul>
												</li>
												<li><a href="index.php">Computer Science and Engineernig <span><img src="pics/rr.png"></span></a>
													<ul>	
														<li><a href="index.php">CSE</a></li>
														<li><a href="index.php">ECE</a></li>
														<li><a href="index.php">EEE</a></li>
													</ul>
												</li>
												<li><a href="index.php">Business Studies <span><img src="pics/rr.png"></span></a>
													<ul>	
														<li><a href="index.php">BBA</a></li>
														<li><a href="index.php">BSS</a></li>
													</ul>
												</li>
												<li><a href="index.php">Fisheries</a>
												<!--<ul>	
														<li><a href="index.php">Fisheries</a></li>
													</ul>-->
												</li>
												<li><a href="index.php">Engineering <span><img src="pics/rr.png"></span></a>
													<ul>	
														<li><a href="index.php">FPE</a></li>
														<li><a href="index.php">AE</a></li>
														<li><a href="index.php">Architechture</a></li>
														<li><a href="index.php">Civil</a></li>
														<li><a href="index.php">Mechanical</a></li>
													</ul>
												</li>
												<li><a href="index.php">Veterinary and Animal Science</a>
												<!--<ul>	
														<li><a href="index.php">DVM</a></li>
													</ul>-->
												</li>
												<li><a href="index.php">Science <span><img src="pics/rr.png"></span></a>
													<ul>	
														<li><a href="index.php">Mathematics</a></li>
														<li><a href="index.php">Statistics</a></li>
														<li><a href="index.php">Chemistry</a></li>
														<li><a href="index.php">Physics</a></li>
													</ul>
												</li>
												<li><a href="index.php">Social Science and Humanitics <span><img src="pics/rr.png"></span></a>
													<ul>	
														<li><a href="index.php">English</a></li>
														<li><a href="index.php">Economics</a></li>
														<li><a href="index.php">Social Science</a></li>
													</ul>
												</li>
												<li><a href="index.php">Postgraduates Studies <span><img src="pics/rr.png"></span></a>
													<ul>	
														<li><a href="index.php">PhD</a></li>
														<li><a href="index.php">MS</a></li>
													</ul>
												</li>
											</ul>
										</li>
										<li><a title="Sheets - স্মরলিপিসমূহ" href="sheets.php">Sheets <span><img src="pics/dd.png"></span></a>
											<ul>
												<li><a href="index.php">Agriculture <span><img src="pics/rr.png"></span></a>
													<ul>	
														<li><a href="index.php">Agriculture</a></li>
														<li><a href="index.php">Agriculture and Agribusiness</a></li>
													</ul>
												</li>
												<li><a href="index.php">Computer Science and Engineernig <span><img src="pics/rr.png"></span></a>
													<ul>	
														<li><a href="index.php">CSE</a></li>
														<li><a href="index.php">ECE</a></li>
														<li><a href="index.php">EEE</a></li>
													</ul>
												</li>
												<li><a href="index.php">Business Studies <span><img src="pics/rr.png"></span></a>
													<ul>	
														<li><a href="index.php">BBA</a></li>
														<li><a href="index.php">BSS</a></li>
													</ul>
												</li>
												<li><a href="index.php">Fisheries</a>
												<!--<ul>	
														<li><a href="index.php">Fisheries</a></li>
													</ul>-->
												</li>
												<li><a href="index.php">Engineering <span><img src="pics/rr.png"></span></a>
													<ul>	
														<li><a href="index.php">FPE</a></li>
														<li><a href="index.php">AE</a></li>
														<li><a href="index.php">Architechture</a></li>
														<li><a href="index.php">Civil</a></li>
														<li><a href="index.php">Mechanical</a></li>
													</ul>
												</li>
												<li><a href="index.php">Veterinary and Animal Science</a>
												<!--<ul>	
														<li><a href="index.php">DVM</a></li>
													</ul>-->
												</li>
												<li><a href="index.php">Science <span><img src="pics/rr.png"></span></a>
													<ul>	
														<li><a href="index.php">Mathematics</a></li>
														<li><a href="index.php">Statistics</a></li>
														<li><a href="index.php">Chemistry</a></li>
														<li><a href="index.php">Physics</a></li>
													</ul>
												</li>
												<li><a href="index.php">Social Science and Humanitics <span><img src="pics/rr.png"></span></a>
													<ul>	
														<li><a href="index.php">English</a></li>
														<li><a href="index.php">Economics</a></li>
														<li><a href="index.php">Social Science</a></li>
													</ul>
												</li>
												<li><a href="index.php">Postgraduates Studies <span><img src="pics/rr.png"></span></a>
													<ul>	
														<li><a href="index.php">PhD</a></li>
														<li><a href="index.php">MS</a></li>
													</ul>
												</li>
											</ul>
										</li>
										<li><a title="Previous Exams' Questions - বিগত পরীক্ষাসমূহের প্রশ্নসমূহ" href="questions.php">Questions <span><img src="pics/dd.png"></span></a>
											<ul>
												<li><a href="index.php">Agriculture <span><img src="pics/rr.png"></span></a>
													<ul>	
														<li><a href="index.php">Agriculture</a></li>
														<li><a href="index.php">Agriculture and Agribusiness</a></li>
													</ul>
												</li>
												<li><a href="index.php">Computer Science and Engineernig <span><img src="pics/rr.png"></span></a>
													<ul>	
														<li><a href="index.php">CSE</a></li>
														<li><a href="index.php">ECE</a></li>
														<li><a href="index.php">EEE</a></li>
													</ul>
												</li>
												<li><a href="index.php">Business Studies <span><img src="pics/rr.png"></span></a>
													<ul>	
														<li><a href="index.php">BBA</a></li>
														<li><a href="index.php">BSS</a></li>
													</ul>
												</li>
												<li><a href="index.php">Fisheries</a>
												<!--<ul>	
														<li><a href="index.php">Fisheries</a></li>
													</ul>-->
												</li>
												<li><a href="index.php">Engineering <span><img src="pics/rr.png"></span></a>
													<ul>	
														<li><a href="index.php">FPE</a></li>
														<li><a href="index.php">AE</a></li>
														<li><a href="index.php">Architechture</a></li>
														<li><a href="index.php">Civil</a></li>
														<li><a href="index.php">Mechanical</a></li>
													</ul>
												</li>
												<li><a href="index.php">Veterinary and Animal Science</a>
												<!--<ul>	
														<li><a href="index.php">DVM</a></li>
													</ul>-->
												</li>
												<li><a href="index.php">Science <span><img src="pics/rr.png"></span></a>
													<ul>	
														<li><a href="index.php">Mathematics</a></li>
														<li><a href="index.php">Statistics</a></li>
														<li><a href="index.php">Chemistry</a></li>
														<li><a href="index.php">Physics</a></li>
													</ul>
												</li>
												<li><a href="index.php">Social Science and Humanitics <span><img src="pics/rr.png"></span></a>
													<ul>	
														<li><a href="index.php">English</a></li>
														<li><a href="index.php">Economics</a></li>
														<li><a href="index.php">Social Science</a></li>
													</ul>
												</li>
												<li><a href="index.php">Postgraduates Studies <span><img src="pics/rr.png"></span></a>
													<ul>	
														<li><a href="index.php">PhD</a></li>
														<li><a href="index.php">MS</a></li>
													</ul>
												</li>
											</ul>
										</li>
										<li><a title="Login - চুক্তিবদ্ধ হোন" href="login.php">Login</a></li>
										<li><a title="About Us - মোদের সম্পর্কে" href="about.php">About</a></li>
										<li><a title="Contact - যোগাযোগ" href="contact.php">Contact</a></li>
										<li><a title="Issue Books || বই প্রেরণ" href="issue.php">Issue Books</a></li>
									</ul>
								</nav>
							</div>
						</b>
					</header>
					
					<main>
						<div id="page_inside">
							<article id="article1">
								<table border="0px" style="width:100%; border-collapse:collapse;">
									<tr>
										<td>
											<h3>
												<br/ > <h1 style="color:maroon" align="center">Books of Computer Science and Engineering</a>
											</h3>
											<br/ >
										</td>
										<td align="right">
											<b class="clockStyle" id="clockDisplay"></b>
										</td>
									</tr>
									<tr>
										<td valign="top" align="center">
											<table border="3" style="background-color:#02DCCB" cellspacing="15" cellpadding="9">
												<tr>
													<td>
														<details>
														<summary><font size="5">Level-1, Semester-i</font></summary>
															<b><ul type="disc">
																<li><a href="http://mxwv7k8vy6.download2.org/dl.php?id=60362044&h=cb3edef928d476ea6bea83d4f049bdaa&u=cache">ANSI C by Balaguruswamy<a></li>
																<li><a href="http://shyam.nitk.ac.in/Books/GT%20Books/DiscMaths4CompSc.pdf">Discrete Mathematics</a></li>
																<li><a href="http://www.iea.org/publications/freepublications/publication/Deploying_Renewables2011.pdf">Agricutural and Industrial Engineering</a></li>
															</ul></b>
														</details>
													</td>
												</tr>
												<tr>
													<td>
														<details>
														<summary><font size="5">Level-1, Semester-ii</font></summary>
															<b><ul type="disc">
																<li><a href="http://rb0bqb4xrw.download2.org/dl.php?id=26350490&h=fca0bf04ff69ad949e7598c950f11a86&u=cache">OOP with C++ by Balaguruswamy<a></li>
																<li><a href="http://shyam.nitk.ac.in/Books/GT%20Books/DiscMaths4CompSc.pdf">Discrete Mathematics</a></li>
																<li><a href="http://www.iea.org/publications/freepublications/publication/Deploying_Renewables2011.pdf">Agricutural and Industrial Engineering</a></li>
															</ul></b>
														</details>
													</td>
												</tr>
												<tr>
													<td>
														<details>
														<summary><font size="5">Level-2, Semester-i</font></summary>
															<b><ul type="disc">
																<li><a href="http://mxwv7k8vy6.download2.org/dl.php?id=60362044&h=cb3edef928d476ea6bea83d4f049bdaa&u=cache">ANSI C by Balaguruswamy<a></li>
																<li><a href="http://shyam.nitk.ac.in/Books/GT%20Books/DiscMaths4CompSc.pdf">Discrete Mathematics</a></li>
																<li><a href="http://www.iea.org/publications/freepublications/publication/Deploying_Renewables2011.pdf">Agricutural and Industrial Engineering</a></li>
															</ul></b>
														</details>
													</td>
												</tr>
												<tr>
													<td>
														<details>
														<summary><font size="5">Level-2, Semester-ii</font></summary>
															<b><ul type="disc">
																<li><a href="http://mxwv7k8vy6.download2.org/dl.php?id=60362044&h=cb3edef928d476ea6bea83d4f049bdaa&u=cache">ANSI C by Balaguruswamy<a></li>
																<li><a href="http://shyam.nitk.ac.in/Books/GT%20Books/DiscMaths4CompSc.pdf">Discrete Mathematics</a></li>
																<li><a href="http://www.iea.org/publications/freepublications/publication/Deploying_Renewables2011.pdf">Agricutural and Industrial Engineering</a></li>
															</ul></b>
														</details>
													</td>
												</tr>
												<tr>
													<td>
														<details>
														<summary><font size="5">Level-3, Semester-i</font></summary>
															<b><ul type="disc">
																<li><a href="http://mxwv7k8vy6.download2.org/dl.php?id=60362044&h=cb3edef928d476ea6bea83d4f049bdaa&u=cache">ANSI C by Balaguruswamy<a></li>
																<li><a href="http://shyam.nitk.ac.in/Books/GT%20Books/DiscMaths4CompSc.pdf">Discrete Mathematics</a></li>
																<li><a href="http://www.iea.org/publications/freepublications/publication/Deploying_Renewables2011.pdf">Agricutural and Industrial Engineering</a></li>
															</ul></b>
														</details>
													</td>
												</tr>
												<tr>
													<td>
														<details>
														<summary><font size="5">Level-3, Semester-ii</font></summary>
															<b><ul type="disc">
																<li><a href="http://mxwv7k8vy6.download2.org/dl.php?id=60362044&h=cb3edef928d476ea6bea83d4f049bdaa&u=cache">ANSI C by Balaguruswamy<a></li>
																<li><a href="http://shyam.nitk.ac.in/Books/GT%20Books/DiscMaths4CompSc.pdf">Discrete Mathematics</a></li>
																<li><a href="http://www.iea.org/publications/freepublications/publication/Deploying_Renewables2011.pdf">Agricutural and Industrial Engineering</a></li>
															</ul></b>
														</details>
													</td>
												</tr>
												<tr>
													<td>
														<details>
														<summary><font size="5">Level-4, Semester-i</font></summary>
															<b><ul type="disc">
																<li><a href="http://mxwv7k8vy6.download2.org/dl.php?id=60362044&h=cb3edef928d476ea6bea83d4f049bdaa&u=cache">ANSI C by Balaguruswamy<a></li>
																<li><a href="http://shyam.nitk.ac.in/Books/GT%20Books/DiscMaths4CompSc.pdf">Discrete Mathematics</a></li>
																<li><a href="http://www.iea.org/publications/freepublications/publication/Deploying_Renewables2011.pdf">Agricutural and Industrial Engineering</a></li>
															</ul></b>
														</details>
													</td>
												</tr>
												<tr>
													<td>
														<details>
														<summary><font size="5">Level-4, Semester-ii</font></summary>
															<b><ul type="disc">
																<li><a href="http://mxwv7k8vy6.download2.org/dl.php?id=60362044&h=cb3edef928d476ea6bea83d4f049bdaa&u=cache">ANSI C by Balaguruswamy<a></li>
																<li><a href="http://shyam.nitk.ac.in/Books/GT%20Books/DiscMaths4CompSc.pdf">Discrete Mathematics</a></li>
																<li><a href="http://www.iea.org/publications/freepublications/publication/Deploying_Renewables2011.pdf">Agricutural and Industrial Engineering</a></li>
															</ul></b>
														</details>
													</td>
												</tr>
											</table>
											
											
										</td >
										
									</tr>
								</table>
								<br />
							</article>
						</div>
					</main>
					
					
					
					<p>Thank You!</p>
				
				
					
					<marquee style="background-color:black; color:white;" scrollamount="6" loop="-1">
						<b>পড়! তোমার প্রভুর নামে, যিনি তোমাকে সৃষ্টি করেছেন</b>
					</marquee>
				</td>
				<td class="r">
				</td>
			</tr>
		</table>
		
		<script type="text/javascript" language="javascript"> 
			function renderTime(){
				var currentTime = new Date();
				var diem = "AM";
				var h = currentTime.getHours();
				var m = currentTime.getMinutes();
				var s = currentTime.getSeconds();
				
				if(h==0){
					h = 12;					
				}
				else if(h>12){
					h=h-12;
					diem="PM";
				}
				if(h<10){
					h = "0" + h;
				}
				if(m<10){
					m = "0" + m;
				}
				if(s<10){
					s = "0" + s;
				}
				
				var myClock = document.getElementById('clockDisplay');
				myClock.textContent = h + ":" + m + ":" + s + " " + diem;
				myClock.innerText = h + ":" + m + ":" + s + " " + diem;
					
				setTimeout('renderTime()',1000);
			}
			renderTime();
		</script>
	</body>
</html>
